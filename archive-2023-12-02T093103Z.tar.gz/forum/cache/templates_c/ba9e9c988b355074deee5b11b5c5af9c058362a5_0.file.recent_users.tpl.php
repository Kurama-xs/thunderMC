<?php
/* Smarty version 4.3.4, created on 2023-11-28 18:01:22
  from '/home/container/webroot/forum/custom/panel_templates/Default/collections/dashboard_stats/recent_users.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_65661ce2a129e8_11911547',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ba9e9c988b355074deee5b11b5c5af9c058362a5' => 
    array (
      0 => '/home/container/webroot/forum/custom/panel_templates/Default/collections/dashboard_stats/recent_users.tpl',
      1 => 1696070954,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65661ce2a129e8_11911547 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="col-xl-3 col-md-6 mb-4">
    <div class="card stats-card border-left-primary shadow h-100 py-2">
        <div class="card-body">
            <div class="row no-gutters align-items-center">
                <div class="col mr-2">
                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"><?php echo $_smarty_tpl->tpl_vars['TITLE']->value;?>
</div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $_smarty_tpl->tpl_vars['VALUE']->value;?>
</div>
                </div>
                <div class="col-auto">
                    <i class="fas fa-users fa-2x text-gray-300"></i>
                </div>
            </div>
        </div>
    </div>
</div>
<?php }
}
