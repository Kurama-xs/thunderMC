<?php

return [
  'mysql' => [
    'host' => '46.149.77.229:3306',
    'port' => '3306',
    'username' => 'u643_AOT3wS9Exk',
    'password' => 'p@LtV8CyhD9lg7RTD+iekiVI',
    'db' => 's643_thunderMC',
    'charset' => 'utf8mb4',
    'collation' => 'utf8mb4_unicode_ci',
    'initialise_charset' => true,
    'initialise_collation' => true,
  ],
  'remember' => [
    'cookie_name' => 'nl2',
    'cookie_expiry' => 604800,
  ],
  'session' => [
    'session_name' => '2user',
    'admin_name' => '2admin',
    'token_name' => '2token',
  ],
  'core' => [
    'hostname' => 'de4.mpmru.tk:25010',
    'path' => 'forum',
    'friendly' => false,
    'force_https' => false,
    'force_www' => false,
    'captcha' => false,
    'date_format' => 'd M Y, H:i',
    'trustedProxies' => NULL,
    'installed' => true,
  ],
];